-- MySQL dump 10.13  Distrib 5.6.33-79.0, for Linux (x86_64)
--
-- Host: localhost    Database: vfmobo6d_vlottery
-- ------------------------------------------------------
-- Server version	5.6.33-79.0-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`userid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`username`, `password`, `userid`) VALUES ('srf','755',3);
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `admin_configuration`
--

DROP TABLE IF EXISTS `admin_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version_code` int(11) NOT NULL,
  `version_name` double NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_configuration`
--

LOCK TABLES `admin_configuration` WRITE;
/*!40000 ALTER TABLE `admin_configuration` DISABLE KEYS */;
INSERT INTO `admin_configuration` (`id`, `version_code`, `version_name`, `status`) VALUES (1,5,5.1,1);
/*!40000 ALTER TABLE `admin_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `agents`
--

DROP TABLE IF EXISTS `agents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `agents` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'main',
  `userid` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(50) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `shop` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `place` varchar(50) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `main_agent` varchar(50) NOT NULL DEFAULT 'NA',
  `insertion_date_time` datetime NOT NULL,
  `inserter` varchar(10) NOT NULL,
  PRIMARY KEY (`userid`),
  KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `agents`
--

LOCK TABLES `agents` WRITE;
/*!40000 ALTER TABLE `agents` DISABLE KEYS */;
INSERT INTO `agents` (`username`, `password`, `role`, `userid`, `phone`, `name`, `shop`, `address`, `place`, `status`, `main_agent`, `insertion_date_time`, `inserter`) VALUES ('ban','ban','collector',1,'9446827218','Banee Ishaque K','NA','NA','NA',0,'NA','2018-08-22 18:41:59','NA');
/*!40000 ALTER TABLE `agents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration`
--

DROP TABLE IF EXISTS `configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration` (
  `cut_time` time NOT NULL DEFAULT '14:45:00',
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `system_status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration`
--

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
INSERT INTO `configuration` (`cut_time`, `id`, `system_status`) VALUES ('13:00:00',1,1);
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent` varchar(50) NOT NULL,
  `insertion_date_time` datetime NOT NULL,
  `received_amount` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_clear`
--

DROP TABLE IF EXISTS `payment_clear`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_clear` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent` varchar(50) NOT NULL,
  `start_date` date NOT NULL DEFAULT '2018-00-00',
  `old_balance` float NOT NULL,
  PRIMARY KEY (`id`),
  KEY `agent` (`agent`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_clear`
--

LOCK TABLES `payment_clear` WRITE;
/*!40000 ALTER TABLE `payment_clear` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_clear` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_automation_configuration`
--

DROP TABLE IF EXISTS `pos_automation_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_automation_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version_code` int(11) NOT NULL,
  `version_name` double NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_automation_configuration`
--

LOCK TABLES `pos_automation_configuration` WRITE;
/*!40000 ALTER TABLE `pos_automation_configuration` DISABLE KEYS */;
INSERT INTO `pos_automation_configuration` (`id`, `version_code`, `version_name`, `status`) VALUES (1,4,4.3,1);
/*!40000 ALTER TABLE `pos_automation_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_configuration`
--

DROP TABLE IF EXISTS `pos_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version_code` int(11) DEFAULT NULL,
  `version_name` double DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_configuration`
--

LOCK TABLES `pos_configuration` WRITE;
/*!40000 ALTER TABLE `pos_configuration` DISABLE KEYS */;
INSERT INTO `pos_configuration` (`id`, `version_code`, `version_name`, `status`) VALUES (1,1,1,1);
/*!40000 ALTER TABLE `pos_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_lite_configuration`
--

DROP TABLE IF EXISTS `pos_lite_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_lite_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version_code` int(11) NOT NULL,
  `version_name` double NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_lite_configuration`
--

LOCK TABLES `pos_lite_configuration` WRITE;
/*!40000 ALTER TABLE `pos_lite_configuration` DISABLE KEYS */;
INSERT INTO `pos_lite_configuration` (`id`, `version_code`, `version_name`, `status`) VALUES (1,5,5.1,1);
/*!40000 ALTER TABLE `pos_lite_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pos_plus_configuration`
--

DROP TABLE IF EXISTS `pos_plus_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pos_plus_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version_code` int(11) NOT NULL,
  `version_name` double NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pos_plus_configuration`
--

LOCK TABLES `pos_plus_configuration` WRITE;
/*!40000 ALTER TABLE `pos_plus_configuration` DISABLE KEYS */;
INSERT INTO `pos_plus_configuration` (`id`, `version_code`, `version_name`, `status`) VALUES (1,1,1,1);
/*!40000 ALTER TABLE `pos_plus_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prize`
--

DROP TABLE IF EXISTS `prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prize` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scheme` varchar(50) NOT NULL,
  `position` int(11) NOT NULL,
  `amount` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `scheme` (`scheme`),
  KEY `position` (`position`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prize`
--

LOCK TABLES `prize` WRITE;
/*!40000 ALTER TABLE `prize` DISABLE KEYS */;
INSERT INTO `prize` (`id`, `scheme`, `position`, `amount`) VALUES (1,'lsk',1,5000),(2,'lsk',2,500),(3,'lsk',3,250),(4,'lsk',4,100),(5,'lsk',5,50),(6,'lsk',6,20),(7,'box',1,3000),(13,'box',4,800),(12,'box',3,800),(11,'box',2,800),(14,'box',5,800),(15,'box',6,800),(16,'a',1,100),(17,'b',1,100),(18,'c',1,100),(19,'ab',1,700),(20,'ac',1,700),(21,'bc',1,700);
/*!40000 ALTER TABLE `prize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reseller_configuration`
--

DROP TABLE IF EXISTS `reseller_configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reseller_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `version_code` int(11) NOT NULL,
  `version_name` double NOT NULL,
  `status` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reseller_configuration`
--

LOCK TABLES `reseller_configuration` WRITE;
/*!40000 ALTER TABLE `reseller_configuration` DISABLE KEYS */;
INSERT INTO `reseller_configuration` (`id`, `version_code`, `version_name`, `status`) VALUES (1,4,4.3,1);
/*!40000 ALTER TABLE `reseller_configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scheme` varchar(50) NOT NULL,
  `date_time` date NOT NULL,
  `serial` varchar(50) NOT NULL,
  `position` int(11) NOT NULL,
  `prize_money` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date_time` (`date_time`),
  KEY `serial` (`serial`),
  KEY `scheme` (`scheme`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `result`
--

LOCK TABLES `result` WRITE;
/*!40000 ALTER TABLE `result` DISABLE KEYS */;
/*!40000 ALTER TABLE `result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resultv`
--

DROP TABLE IF EXISTS `resultv`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resultv` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scheme` varchar(50) NOT NULL,
  `date_time` date NOT NULL,
  `serial` varchar(50) NOT NULL,
  `position` int(11) NOT NULL,
  `prize_money` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date_time` (`date_time`),
  KEY `serial` (`serial`),
  KEY `scheme` (`scheme`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resultv`
--

LOCK TABLES `resultv` WRITE;
/*!40000 ALTER TABLE `resultv` DISABLE KEYS */;
/*!40000 ALTER TABLE `resultv` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheme_limits`
--

DROP TABLE IF EXISTS `scheme_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `scheme_limits` (
  `ticket_scheme` varchar(50) NOT NULL,
  `scheme_limit` int(11) NOT NULL DEFAULT '300',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `position` int(11) NOT NULL,
  PRIMARY KEY (`ticket_scheme`),
  UNIQUE KEY `ticket_scheme` (`ticket_scheme`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheme_limits`
--

LOCK TABLES `scheme_limits` WRITE;
/*!40000 ALTER TABLE `scheme_limits` DISABLE KEYS */;
INSERT INTO `scheme_limits` (`ticket_scheme`, `scheme_limit`, `active`, `position`) VALUES ('AC',200,1,8),('BC',200,1,7),('AB',200,1,6),('C',3500,1,5),('B',3500,1,4),('A',3500,1,3),('LSK',2000,1,1),('BOX',1000,1,2);
/*!40000 ALTER TABLE `scheme_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_no` int(11) NOT NULL,
  `serial` varchar(50) NOT NULL,
  `count` int(11) NOT NULL,
  `agent` varchar(50) NOT NULL,
  `scheme` varchar(50) NOT NULL,
  `amount` float NOT NULL,
  `insertion_date` date NOT NULL,
  `insertion_time` datetime NOT NULL,
  `delete_status` tinyint(4) DEFAULT '0',
  `delete_time_stamp` datetime DEFAULT NULL,
  `deleter` varchar(10) DEFAULT NULL,
  `inserter` varchar(10) DEFAULT 'POS',
  PRIMARY KEY (`id`),
  KEY `scheme` (`scheme`),
  KEY `insertion_date` (`insertion_date`),
  KEY `insertion_time` (`insertion_time`),
  KEY `delete_status` (`delete_status`),
  KEY `agent` (`agent`),
  KEY `bill_no` (`bill_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket_limits`
--

DROP TABLE IF EXISTS `ticket_limits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket_limits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `serial_number` varchar(50) NOT NULL,
  `limit` int(11) NOT NULL,
  `draw_date` date NOT NULL,
  `ticket_scheme` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_limits`
--

LOCK TABLES `ticket_limits` WRITE;
/*!40000 ALTER TABLE `ticket_limits` DISABLE KEYS */;
INSERT INTO `ticket_limits` (`id`, `serial_number`, `limit`, `draw_date`, `ticket_scheme`) VALUES (1,'736',10,'2018-03-07','LSK'),(2,'125',88,'2018-03-07','LSK'),(3,'128',50,'2018-03-08','LSK'),(4,'129',50,'2018-03-08','LSK');
/*!40000 ALTER TABLE `ticket_limits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'vfmobo6d_vlottery'
--

--
-- Dumping routines for database 'vfmobo6d_vlottery'
--
/*!50003 DROP FUNCTION IF EXISTS `get_agent_money` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`vfmobo6d_ndk`@`localhost` FUNCTION `get_agent_money`(`agent` VARCHAR(50), `scheme` VARCHAR(5), `position` INT) RETURNS float
BEGIN
    DECLARE agent_money FLOAT;
	
	CASE scheme
      WHEN 'LSK' THEN 
		CASE position
			WHEN 1 THEN SELECT agent_money_lsk1 INTO agent_money FROM agents WHERE username = agent;
			WHEN 2 THEN SELECT agent_money_lsk2 INTO agent_money FROM agents WHERE username = agent;
			WHEN 3 THEN SELECT agent_money_lsk3 INTO agent_money FROM agents WHERE username = agent;
			WHEN 4 THEN SELECT agent_money_lsk4 INTO agent_money FROM agents WHERE username = agent;
			WHEN 5 THEN SELECT agent_money_lsk5 INTO agent_money FROM agents WHERE username = agent;
			ELSE
				BEGIN
					SELECT agent_money_lsk6 INTO agent_money FROM agents WHERE username = agent;
				END;
		END CASE;
      WHEN 'BOX' THEN 
		CASE position
			WHEN 1 THEN SELECT agent_money_box1 INTO agent_money FROM agents WHERE username = agent;
			ELSE
				BEGIN
					SELECT agent_money_box2 INTO agent_money FROM agents WHERE username = agent;
				END;
		END CASE;
	  WHEN 'AB' THEN SELECT agent_money_ab INTO agent_money FROM agents WHERE username = agent;
	  WHEN 'BC' THEN SELECT agent_money_ab INTO agent_money FROM agents WHERE username = agent;
	  WHEN 'AC' THEN SELECT agent_money_ab INTO agent_money FROM agents WHERE username = agent;
	  WHEN 'A' THEN SELECT agent_money_a INTO agent_money FROM agents WHERE username = agent;
	  WHEN 'B' THEN SELECT agent_money_a INTO agent_money FROM agents WHERE username = agent;
	  WHEN 'C' THEN SELECT agent_money_a INTO agent_money FROM agents WHERE username = agent;
      ELSE
        BEGIN
        END;
    END CASE;
 
 RETURN (agent_money);
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `get_sub_agent_sale_day` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`vfmobo6d_ndk`@`localhost` FUNCTION `get_sub_agent_sale_day`(`main_agent` VARCHAR(50), `sub_agent` VARCHAR(50), `insert_date` DATE) RETURNS double
BEGIN
    DECLARE agent_sale_amount DOUBLE;
	
	DECLARE agent_rate_a FLOAT;
	DECLARE agent_rate_ab FLOAT;
	DECLARE agent_rate_abc FLOAT;
	
	DECLARE var_count INT;
	DECLARE var_scheme VARCHAR(5);
	
	DECLARE done INT DEFAULT FALSE;
	DECLARE cur1 CURSOR FOR SELECT `count`,`scheme` FROM `ticket` WHERE `agent`=sub_agent AND `insertion_date`=insert_date AND `delete_status`=0;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	
	SELECT A,AB,ABC INTO agent_rate_a,agent_rate_ab,agent_rate_abc FROM agents WHERE username = main_agent;
	
	SET agent_sale_amount=0;

	OPEN cur1;
	
	read_loop: LOOP
		
		FETCH cur1 INTO var_count, var_scheme;
		
		IF done THEN
		  LEAVE read_loop;
		END IF;
		
		CASE var_scheme
		  WHEN 'LSK' THEN SET agent_sale_amount=agent_sale_amount+(var_count*agent_rate_abc);
		  WHEN 'BOX' THEN SET agent_sale_amount=agent_sale_amount+(var_count*agent_rate_abc);
		  WHEN 'AB' THEN SET agent_sale_amount=agent_sale_amount+(var_count*agent_rate_ab);
		  WHEN 'BC' THEN SET agent_sale_amount=agent_sale_amount+(var_count*agent_rate_ab);
		  WHEN 'AC' THEN SET agent_sale_amount=agent_sale_amount+(var_count*agent_rate_ab);
		  WHEN 'A' THEN SET agent_sale_amount=agent_sale_amount+(var_count*agent_rate_a);
		  WHEN 'B' THEN SET agent_sale_amount=agent_sale_amount+(var_count*agent_rate_a);
		  WHEN 'C' THEN SET agent_sale_amount=agent_sale_amount+(var_count*agent_rate_a);
		  ELSE
			BEGIN
			END;
		END CASE;
		
	END LOOP;
	
	CLOSE cur1;

	RETURN agent_sale_amount;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_sale_scheme_serial_count` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`vfmobo6d_ndk`@`localhost` PROCEDURE `get_sale_scheme_serial_count`(IN `input_sale_date` DATE, IN `input_scheme` VARCHAR(10))
    MODIFIES SQL DATA
BEGIN
	
	DECLARE `var_serial` VARCHAR(10);
	
	DECLARE `done` INT DEFAULT FALSE;

	DECLARE `cur1` CURSOR FOR SELECT DISTINCT `serial` FROM `ticket` WHERE `scheme`=`input_scheme` AND `insertion_date`=`input_sale_date` AND `delete_status`=0;

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET `done` = TRUE;
	
	DROP TABLE IF EXISTS `sale_scheme_serial_count`;
	CREATE TEMPORARY TABLE IF NOT EXISTS `sale_scheme_serial_count` (
		`serial` VARCHAR(10) NOT NULL,
		`serial_count` INT NOT NULL
	) ENGINE=MyISAM DEFAULT CHARSET=latin1;

	OPEN `cur1`;
	
	read_loop: LOOP
		
            FETCH `cur1` INTO `var_serial`;

            IF `done` THEN
              LEAVE read_loop;
            END IF;

                                                                                                                                                                                    
            INSERT INTO `sale_scheme_serial_count`(`serial`, `serial_count`) 
            SELECT `var_serial`,SUM(`count`) AS `serial_count` FROM `ticket` WHERE  `scheme`=`input_scheme` AND `insertion_date`=`input_sale_date` AND `serial`=`var_serial` AND `delete_status`=0;
		
	END LOOP;
	
	CLOSE cur1;
	
	SELECT `serial`, `serial_count` AS `count` FROM `sale_scheme_serial_count` ORDER BY `serial` DESC;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-08-30 19:36:31
